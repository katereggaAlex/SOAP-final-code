class Gender_model{

  final String male;
  final String female;

  Gender_model({this.male, this.female});

}