import 'package:firebase_auth/firebase_auth.dart';
import 'package:online_admissions3/services/database.dart';

import '../user-model.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  // create user obj based on FirebaseUser
  User _userFromFirebaseUser(FirebaseUser user) {
    return user != null ? User(uid: user.uid) : null;
  }

  // auth change user stream
  Stream<User> get user {
    return _auth.onAuthStateChanged
        //.map((FirebaseUser user) => _userFromFirebaseUser(user));
        .map(_userFromFirebaseUser);
  }

  //sign in anon
  Future signInAnon() async {
    try {
      AuthResult result = await _auth.signInAnonymously();
      FirebaseUser user = result.user;

      // create a new document for the user with the uid
      await DatabaseService(uid: user.uid).updateUserData(
        'firstName',
        'middleName',
        'lastName',
        'address',
        'nationality',
        'residence',
        'email',
        'mobileNum',
        'disability',
        'gender',
        'parent_name',
        'parent_email',
        'parent_phone1',
        'parent_phone2',
        'parent_city',
        'parent_country',
        'parent_nin',
        'parent_nationality',
        'former_school',
        'former_class',
      );

      return _userFromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  //sign in with email & password
  Future signInWithEmailAndPassword(String email, String password) async {
    try {
      AuthResult result = await _auth.signInWithEmailAndPassword(
          email: email, password: password);
      FirebaseUser user = result.user;
      return _userFromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  //register with email & password
  Future registerWithEmailAndPassword(String email, String password) async {
    try {
      AuthResult result = await _auth.createUserWithEmailAndPassword(
          email: email, password: password);
      FirebaseUser user = result.user;

      // create a new document for the user with the uid

      await DatabaseService(uid: user.uid).updateUserData(
        'firstName',
        'middleName',
        'lastName',
        'address',
        'nationality',
        'residence',
        'email',
        'mobileNum',
        'disability',
        'gender',
        'parent_name',
        'parent_email',
        'parent_phone1',
        'parent_phone2',
        'parent_city',
        'parent_country',
        'parent_nin',
        'parent_nationality',
        'former_school',
        'former_class',
      );
      return _userFromFirebaseUser(user);
    } catch (e) {
      print(e.toString());
      return null;
    }
  }

  // sign out
  Future signOut() async {
    try {
      return await _auth.signOut();
    } catch (e) {
      print(e.toString());
      return null;
    }
  }
}
