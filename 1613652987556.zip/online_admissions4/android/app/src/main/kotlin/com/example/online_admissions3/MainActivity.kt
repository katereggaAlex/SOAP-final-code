package com.example.online_admissions3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
